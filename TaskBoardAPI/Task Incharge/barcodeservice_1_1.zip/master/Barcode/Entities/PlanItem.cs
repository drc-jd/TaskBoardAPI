﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barcode.Entities {
    public class PlanItem {
        public int id { get; set; }
        public int planId { get; set; }
        public int kapanId { get; set; }
        public string kapanName { get; set; }
        public int packetId { get; set; }
        public int? packetNo { get; set; }
        public string subPcs { get; set; }
        public string shape { get; set; }
        public string purity { get; set; }
        public string color { get; set; }
        public string secColor { get; set; }
        public string cut { get; set; }
        public string polish { get; set; }
        public string symmetry { get; set; }
        public string florecent { get; set; }
        public int tantion { get; set; }
        public decimal? depth { get; set; }
        public decimal? ratio { get; set; }
        public decimal polishWt { get; set; }
        public decimal roughWt { get; set; }
        public decimal? rate { get; set; }
        public decimal? secRate { get; set; }
        public decimal? discount { get; set; }
        public decimal? secDiscount { get; set; }
        public decimal amount { get; set; }
        public decimal? secAmount { get; set; }
        public decimal oAmount { get; set; }
        public decimal? secOAmount { get; set; }
        public decimal? pCAvg { get; set; }
        public string rapVer { get; set; }
        public int empId { get; set; }
        public string empCode { get; set; }
        public bool isApproved { get; set; }
        public bool? isVerified { get; set; }
        public bool isDamagePlan { get; set; }
        public bool hasPlanFile { get; set; }
        public DateTime? createDate { get; set; }
        public string remark;
        public string lab { get; set; }

        public string brown { get; set; }
        public string green { get; set; }
        public string milky { get; set; }
        public string shade { get; set; }
        public string sideBlack { get; set; }
        public string tableBlack { get; set; }
        public string sideWhite { get; set; }
        public string tableWhite { get; set; }
        public string openCrown { get; set; }
        public string openPavilion { get; set; }
        public string openGirdle { get; set; }
        public string openTable { get; set; }
        public string natural { get; set; }
        public string naturalCrown { get; set; }
        public string naturalPavilion { get; set; }
        public string hNA { get; set; }

        public string culet { get; set; }
        public string eFCrown { get; set; }
        public string eFPavilion { get; set; }
        public string eyeClean { get; set; }
        public string fLColor { get; set; }
        public string girdle { get; set; }
        public string luster { get; set; }
        public string tinge { get; set; }
        public string girdleCondition { get; set; }
        public string graining { get; set; }
        public decimal? diameter { get; set; }
        public decimal? tablePer { get; set; }
        public decimal? crAng { get; set; }
        public decimal? pavAng { get; set; }
        public int? solutionNo { get; set; }

        public PlanItem() { }

    }
}
