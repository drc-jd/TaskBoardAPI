﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barcode.Entities {
    public class PlanPrintInput {
        public string empCode { get; set; }
        public string kapanName { get; set; }
        public int packetNo { get; set; }
        public string subPcs { get; set; }
        public List<PlanItem> plans { get; set; }
    }
}
