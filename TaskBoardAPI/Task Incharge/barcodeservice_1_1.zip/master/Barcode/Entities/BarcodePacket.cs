﻿using System;

namespace Barcode.Entities {
    public class BarcodePacket {
        public int id { get; set; }
        public string kapanName { get; set; }
        public int packetNo { get; set; }
        public string subPcs { get; set; }
        public decimal? weight { get; set; }
        public string color { get; set; }
        public int? tantion { get; set; }
        public string florocent { get; set; }
        private string _createDate;
        public string createDate {
            get { return _createDate; }
            set {
                _createDate = value;
                if(!string.IsNullOrEmpty(value)) {
                    this.FinalDate = DateTime.Parse(value, null, System.Globalization.DateTimeStyles.RoundtripKind);
                }
            }
        }
        public DateTime FinalDate { get; set; }
    }

    public class MumbaiBarcodePacket {
        public int packetId { get; set; }
        public string kapanName { get; set; }
        public int packetNo { get; set; }
        public string subPcs { get; set; }
        public string purity { get; set; }
        public string florocent { get; set; }
        public string cut { get; set; }
        public string polish { get; set; }
        public string symmetry { get; set; }
        public string shape { get; set; }
        public decimal weight { get; set; }
        public string color { get; set; }
        public decimal rate { get; set; }
        public decimal discount { get; set; }
        public decimal amount { get; set; }
        public decimal? height { get; set; }
        public decimal? diaAvg { get; set; }
    }
}
