﻿using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;

namespace Barcode {
    public class JSonHelper {
        public static T Deserialise<T>(string json) {
            T obj = Activator.CreateInstance<T>();
            MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json));
            DataContractJsonSerializer serialiser = new DataContractJsonSerializer(obj.GetType());
            obj = (T)serialiser.ReadObject(ms);
            ms.Close();
            return obj;
        }
    }
}
