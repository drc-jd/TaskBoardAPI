﻿using System;
using System.IO;

namespace Barcode {
    public class Logger {

        private static readonly Object lockThis = new Object();
        public static bool writeFile = false;
        public static bool showMessageBox = false;
        
        public static void WriteLog(string message) {
            try {
                if(writeFile) {
                    StreamWriter sw = null;
                    lock (lockThis) {
                        sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\" + DateTime.Today.ToString("ddMMyyyy") + ".txt", true);
                        sw.WriteLine(DateTime.Now.ToString() + ":" + message);
                        sw.Flush();
                        sw.Close();
                    }
                }                
            }
            catch (Exception) {

            }

        }
        public static void ShowMessageBox(string message) {
            if(showMessageBox)
                System.Windows.Forms.MessageBox.Show(message);
        }
    }
}
