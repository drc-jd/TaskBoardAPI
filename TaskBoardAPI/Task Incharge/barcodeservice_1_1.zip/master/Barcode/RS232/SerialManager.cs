﻿using System;
using System.IO.Ports;
using System.Text;

namespace Barcode.RS232 {
    public class SerialManager : RS232Settings {
        internal static SerialPort DataserialPort;
        internal static int check = 0;
        internal static string EquipmentName = "";

        public static bool writeToSerialPort(string strData) {
            bool flag = false;
            if (APPEND_NEWLINE) {
                strData = strData + "\n";
            }
            if (APPEND_CARRIAGE_RETURN) {
                strData = strData + "\r";
            }

            try {
                DataserialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
                DataserialPort.Write(strData);
                flag = true;
            }
            catch (Exception ex) {
                Console.WriteLine(ex);
                Logger.WriteLog(ex.Message);
                flag = false;
            }

            return flag;
        }
        public static bool writeToSerialPort(char charData) {
            bool flag = false;
            StringBuilder data = new StringBuilder();
            data.Append(charData);
            try {
                DataserialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
                DataserialPort.Write(charData.ToString());
                flag = true;
                string charValue = data.ToString();
                int c = int.Parse(charData.ToString());
                switch (c) {
                    case 0x00:
                        charValue = "<NUL>";
                        break;
                    case 0x0D:
                        charValue = "<CR>";
                        break;
                    case 0x0A:
                        charValue = "<LF>";
                        break;
                    case 0x15:
                        charValue = "<NAK>";
                        break;
                    case 0x06:
                        charValue = "<ACK>";
                        break;
                    case 0x05:
                        charValue = "<ENQ>";
                        break;
                    case 0x04:
                        charValue = "<EOT>";
                        break;
                    case 0x03:
                        charValue = "<ETX>";
                        break;
                    case 0x02:
                        charValue = "<STX>";
                        break;

                }
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }

            return flag;
        }
        public static string readFromSerialPort() {
            string data = "";
            SerialPort serialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
            try {
                serialPort.Open(); //Open serial port
                data = serialPort.ReadLine(); //Read data from serial port
                serialPort.Close(); //Close serial port
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return data;
        }
        public static bool openPort() {
            bool flag = false;
            SerialPort serialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
            try {
                serialPort.Open();
                serialPort.Close();
                flag = true;
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return flag;
        }

        public static bool closeOpenedPort() {
            bool flag = false;
            try {
                if (DataserialPort.IsOpen) {
                    DataserialPort.Close();
                }
                flag = true;
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return flag;
        }
        public static bool ResetPort() {
            bool flag = false;
            try {
                if (DataserialPort.IsOpen) {
                    DataserialPort.Close();
                }

                DataserialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
                DataserialPort.Open();
                DataserialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler); //Add SerialPortEventListener

                flag = true;
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return flag;
        }
        public static bool openPortforData(string equipment) {
            bool flag = false;
            SerialManager.EquipmentName = equipment;
            try {
                if (!string.IsNullOrEmpty(COMPORT) && BAUD > 0 && DATABIT_LENGTH > 0 && STOPBIT > 0) {
                    DataserialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
                    DataserialPort.Open();
                    DataserialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                    flag = true;
                }
                else
                    flag = false;
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return flag;
        }
        public static bool openPortforDataAlt(string equipment) {
            bool flag = false;
            SerialManager.EquipmentName = equipment;
            DataserialPort = new SerialPort(COMPORT, BAUD, PARITY, DATABIT_LENGTH, STOPBIT);
            try {
                DataserialPort.Open();
                DataserialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                flag = true;
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
            return flag;
        }
        private static void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e) {
            try {
                SerialPort sp = (SerialPort)sender;
                byte[] data = new byte[sp.BytesToRead];
                sp.Read(data, 0, data.Length);
                string buffer = ASCIIEncoding.ASCII.GetString(data);
                if (!string.IsNullOrEmpty(buffer)) {
                    //SYSMEXKX21N.HandleDataInput(buffer);
                }
            }
            catch (Exception ex) {
                Logger.WriteLog(ex.Message);
            }
        }

    }
}
