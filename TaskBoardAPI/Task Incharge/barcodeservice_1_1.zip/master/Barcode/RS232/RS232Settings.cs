﻿using System.IO.Ports;

namespace Barcode.RS232 {
    public class RS232Settings {
        public static string COMPORT;
        public static int BAUD;
        public static Parity PARITY;
        public static StopBits STOPBIT;
        public static int DATABIT_LENGTH;
        public static bool APPEND_NEWLINE;
        public static bool APPEND_CARRIAGE_RETURN;
        public static Handshake Handshake;
    }
}
