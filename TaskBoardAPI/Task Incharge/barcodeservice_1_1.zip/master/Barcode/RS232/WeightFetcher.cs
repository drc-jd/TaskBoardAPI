﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barcode.RS232 {
    public class WeightFetcher : BaseThread {
        public override void Run() {
            if (SerialManager.openPortforData("Balance")) {
                Logger.WriteLog("Interfacing for Blance.");
            }
        }

        public virtual void Stop() {
            if (SerialManager.closeOpenedPort()) {
                Logger.WriteLog("Interfacing Closed for Balance.");
            }
        }
    }
}
