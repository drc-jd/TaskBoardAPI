﻿using Barcode.Entities;
using Barcode.Properties;
using Barcode.RS232;
using DataClass;
using IWshRuntimeLibrary;
using SDK_SC_RFID_Devices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace Barcode {
    public partial class Form1 : Form {
        SerialSettings _currentSerialSettings;
        private int BarcodeStyleNo = 1;
        private int PlanPrintNo = 2;

        HttpListener _listener;
        SerialPort sp;
        Thread _serverThread;
        string BufferString = string.Empty;
        bool serverFlag = true;
        decimal? WT_DATA;
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }
        public Form1() {
            InitializeComponent();
            if (!string.IsNullOrEmpty(Settings.Default.WriteFile)) {
                try {
                    BarcodeStyleNo = Convert.ToInt32(Settings.Default.BarcodeNo);
                    PlanPrintNo = Convert.ToInt32(Settings.Default.PlanPrintNo);
                    Logger.writeFile = Convert.ToBoolean(Settings.Default.WriteFile);
                    Logger.showMessageBox = Convert.ToBoolean(Settings.Default.MessageBox);
                }
                catch (Exception) {
                }
            }
            this.UserInitialization();
        }

        private void UserInitialization() {
           this.WindowState = FormWindowState.Minimized;
           this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.txtAPI.Text = Settings.Default.WebPort;

            this.InitializationSerialManager();
            this.FormClosing += new FormClosingEventHandler(MainForm_FormClosing);
        }
        private void InitializationSerialManager() {
            try {
                _currentSerialSettings = new SerialSettings();
                _currentSerialSettings.PortNameCollection = SerialPort.GetPortNames();
                _currentSerialSettings.PropertyChanged += _currentSerialSettings_PropertyChanged;

                if (!string.IsNullOrEmpty(Settings.Default.COMPORT) &&
                    Settings.Default.BAUD > 0 && Settings.Default.DATABIT_LENGTH > 0) {
                    baudRateComboBox.SelectedItem = Settings.Default.BAUD;
                    dataBitsComboBox.SelectedItem = Settings.Default.DATABIT_LENGTH;
                    parityComboBox.SelectedItem = Settings.Default.PARITY;
                    stopBitsComboBox.SelectedItem = Settings.Default.STOPBIT;

                    RS232Settings.COMPORT = Settings.Default.COMPORT;
                    RS232Settings.BAUD = Settings.Default.BAUD;
                    RS232Settings.DATABIT_LENGTH = Settings.Default.DATABIT_LENGTH;
                    RS232Settings.PARITY = Settings.Default.PARITY;
                    RS232Settings.STOPBIT = Settings.Default.STOPBIT;
                    RS232Settings.Handshake = Settings.Default.HandShake;

                    this.RunInterfacer();
                }
            }
            catch (Exception ex) {
                Logger.WriteLog("InitializationSerialManager");
                Logger.WriteLog(ex.Message + ex.InnerException.Message);
            }
        }
        private void _currentSerialSettings_PropertyChanged(object sender, PropertyChangedEventArgs e) {
            // if serial port is changed, a new baud query is issued
            if (e.PropertyName.Equals("PortName"))
                UpdateBaudRateCollection();
        }
        private void UpdateBaudRateCollection() {
            if (_currentSerialSettings.PortNameCollection != null && _currentSerialSettings.PortNameCollection.Length > 0
               && !string.IsNullOrEmpty(_currentSerialSettings.PortName) && _currentSerialSettings.PortNameCollection.Contains(_currentSerialSettings.PortName)) {
                var _serialPort = new SerialPort(_currentSerialSettings.PortName);
                Logger.WriteLog("Port Name: " + _currentSerialSettings.PortName);
                _serialPort.Open();
                object p = _serialPort.BaseStream.GetType().GetField("commProp", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(_serialPort.BaseStream);
                Int32 dwSettableBaud = (Int32)p.GetType().GetField("dwSettableBaud", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).GetValue(p);

                _serialPort.Close();
                _currentSerialSettings.UpdateBaudRateCollection(dwSettableBaud);
            }
        }

        private void RunInterfacer() {
            try {
                Logger.WriteLog("Default Settings");
                Logger.WriteLog(Environment.NewLine + "ComPort : " + RS232Settings.COMPORT + Environment.NewLine + "BAUD :" + RS232Settings.BAUD.ToString() + Environment.NewLine +
                                    "DATABIT_LENGTH :" + RS232Settings.DATABIT_LENGTH + Environment.NewLine + "PARITY : " + RS232Settings.PARITY + Environment.NewLine +
                                     "STOPBIT : " + RS232Settings.STOPBIT + Environment.NewLine + "HandShake : " + RS232Settings.Handshake);
                if (!string.IsNullOrEmpty(Settings.Default.COMPORT) && Settings.Default.BAUD > 0
                                && Settings.Default.DATABIT_LENGTH > 0 && !string.IsNullOrEmpty(Settings.Default.WebPort)) {

                    //intialize SerialSetting
                    RS232Settings.COMPORT = Settings.Default.COMPORT;
                    RS232Settings.BAUD = Settings.Default.BAUD;
                    RS232Settings.DATABIT_LENGTH = Settings.Default.DATABIT_LENGTH;
                    RS232Settings.PARITY = Settings.Default.PARITY;
                    RS232Settings.STOPBIT = Settings.Default.STOPBIT;
                    sp = new SerialPort(RS232Settings.COMPORT, RS232Settings.BAUD, RS232Settings.PARITY,
                        RS232Settings.DATABIT_LENGTH, RS232Settings.STOPBIT);
                    sp.Handshake = RS232Settings.Handshake;

                    Logger.WriteLog("Serial Port Settings :");
                    Logger.WriteLog(Environment.NewLine + "ComPort : " + sp.PortName + Environment.NewLine + "BAUD :" + sp.BaudRate.ToString() + Environment.NewLine +
                                    "DATABIT_LENGTH :" + sp.DataBits.ToString() + Environment.NewLine + "PARITY : " + sp.Parity.ToString() + Environment.NewLine +
                                    "STOPBIT : " + sp.StopBits.ToString() + Environment.NewLine + "HandShake : " + sp.Handshake.ToString());
                    sp.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
                    //sp.ErrorReceived += new SerialErrorReceivedEventHandler(port_ErrorReceived);
                    _serverThread = new Thread(this.Listen);
                    try {
                        _serverThread.Start();
                    }
                    catch (Exception exi) {
                        Logger.WriteLog(exi.Message);
                    }

                }
            }
            catch (Exception ex) {
                Logger.WriteLog("RunInterfacer");
            }
        }
        private void Listen() {
            if (!string.IsNullOrEmpty(Settings.Default.WebPort)) {
                string port = Settings.Default.WebPort;
                try {
                    Logger.WriteLog("Listening On WebPort:" + Settings.Default.WebPort.ToLower());
                    _listener = new HttpListener();
                    _listener.Prefixes.Add("http://127.0.0.1:" + port + "/");
                    _listener.Start();
                    while (serverFlag) {
                        try {
                            HttpListenerContext context = _listener.GetContext();
                            if (context.Request.HttpMethod == "GET")
                                GetWeightFromScale(context);
                            else
                                ProcessBarcodePrint(context);
                        }
                        catch (Exception ex) {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void ProcessBarcodePrint(HttpListenerContext context) {
            try {
                string finalResponse = "Error";
                using (var reader = new StreamReader(context.Request.InputStream)) {
                    var content = reader.ReadToEnd();
                    if (!string.IsNullOrEmpty(content)) {
                        try {
                            if (context.Request.RawUrl.ToLower() == "/normal") {
                                //print
                            }
                            else if (context.Request.RawUrl.ToLower() == "/print") {
                                var input = JSonHelper.Deserialise<PlanPrintInput>(content);
                                if (input != null && input.plans.Count > 0) {
                                    string printer = RawPrinterHelper.GetDefaultPrinter();
                                    if (!string.IsNullOrEmpty(printer)) {
                                       //print
                                        finalResponse = "Success";
                                    }
                                    else
                                        finalResponse = "Default Printer Not Found";
                                }
                                else
                                    finalResponse = "Not Found";
                            }
                        }
                        catch (Exception ex) {
                            finalResponse = ex.Message;
                        }
                    }
                    else
                        finalResponse = "Invalid Input";

                    //create response
                    context.Response.ContentType = "text/plain";
                    if (context.Request.HttpMethod == "OPTIONS") {
                        context.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept, X-Requested-With");
                        context.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                        context.Response.AddHeader("Access-Control-Max-Age", "1728000");
                    }
                    context.Response.AddHeader("Access-Control-Allow-Origin", "*");

                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes(finalResponse);
                    context.Response.ContentLength64 = buffer.Length;

                    System.IO.Stream output = context.Response.OutputStream;
                    output.Write(buffer, 0, buffer.Length);
                    output.Close();


                    context.Response.StatusCode = (int)HttpStatusCode.OK;
                    context.Response.OutputStream.Flush();
                }
            }
            catch (Exception ex) {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }
            context.Response.OutputStream.Close();
        }
        private void GetWeightFromScale(HttpListenerContext context) {
            try {

                string input = string.Empty;
                if (context.Request.RawUrl.ToLower() == "/favicon.ico") { return; }
                if (context.Request.RawUrl.ToLower() == "/test") {
                    Logger.WriteLog("Received Test Request");
                    input = "Got Test Request !!!!";
                }
                else {
                    Logger.WriteLog("Received Weight Request");
                    if (sp != null) {
                        Logger.ShowMessageBox("Got Serial Port");
                        //start serial port reader
                        char cCHR27 = (char)27;
                        sp.ReadTimeout = 90000;
                        if (sp.IsOpen) sp.Close();
                        sp.Open();
                        Logger.ShowMessageBox(" Serial Port Opened");
                        sp.DtrEnable = true;
                        if (Settings.Default.HandShake == Handshake.None)
                            sp.Write(cCHR27 + "P");
                        Logger.ShowMessageBox(" Serial Port Data Written");
                        TimeSpan timeSpan = new TimeSpan(0, 1, 30);
                        int elepsedTime = 0;
                        bool flag = true;
                        if (WT_DATA != null)
                            flag = false;
                        Logger.ShowMessageBox("Set Initial Flag True");
                        while (flag) {
                            //Logger.ShowMessageBox("Inside While Loop " + WT_DATA.ToString());
                            if (WT_DATA != null) {
                                flag = false;
                                Logger.ShowMessageBox("Set Flag False");
                            }
                            if (flag) {
                                Thread.Sleep(1000);
                                elepsedTime += 1000;
                                if (elepsedTime > timeSpan.TotalMilliseconds) {
                                    flag = false;
                                    Logger.ShowMessageBox("Set Flag False");
                                    Logger.WriteLog("Weight Request TimeOut");
                                }
                            }
                        }

                        if (WT_DATA.HasValue && WT_DATA.Value > 0) {
                            Logger.ShowMessageBox("Data To Output :" + Convert.ToString(WT_DATA));
                            input = WT_DATA.ToString();
                        }
                        else
                            input = "Please try again!";

                    }
                    else
                        input = "COM Port Not Found!";
                }

                context.Response.ContentType = "text/plain";
                if (context.Request.HttpMethod == "OPTIONS") {
                    context.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept, X-Requested-With");
                    context.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                    context.Response.AddHeader("Access-Control-Max-Age", "1728000");
                }
                context.Response.AddHeader("Access-Control-Allow-Origin", "*");

                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(input);
                context.Response.ContentLength64 = buffer.Length;

                System.IO.Stream output = context.Response.OutputStream;
                output.Write(buffer, 0, buffer.Length);
                output.Close();

                this.WT_DATA = null;

                context.Response.StatusCode = (int)HttpStatusCode.OK;
                context.Response.OutputStream.Flush();

            }
            catch (Exception ex) {
                Logger.ShowMessageBox(ex.Message);
                Logger.WriteLog(ex.Message);
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }

            context.Response.OutputStream.Close();
        }

        private void port_ErrorReceived(object sender, SerialErrorReceivedEventArgs e) {
            try {
                Logger.WriteLog("Port Error :: " + e.EventType);
            }
            catch (Exception ex) {
                Logger.WriteLog("Error when parsing Serial Port ");
                Logger.WriteLog("Message: " + ex.Message);
                Logger.WriteLog("Inner Exception: " + ex.InnerException);
                Logger.WriteLog("Stack Trace: " + ex.StackTrace);
                Logger.WriteLog("Full Stack Trace: " + ex.Data.ToString());
            }
        }
        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e) {
            try {
                string receved = sp.ReadExisting();
                Logger.WriteLog("Data Received : " + receved);
                this.BufferString += receved;
                if (receved.EndsWith("\n") || receved.EndsWith("\r")) {
                    char[] charray = { ' ', 'N', '+', 'c', 't', '\r', '\n' };
                    string trimed = BufferString.Trim(charray);
                    decimal weight = 0;
                    Logger.WriteLog("Trimmed Data:" + trimed);
                    if (decimal.TryParse(trimed, out weight)) {
                        if (weight > 0) {
                            WT_DATA = weight;
                            Logger.ShowMessageBox("Final Weight Received From kati: " + WT_DATA.Value.ToString());
                            Logger.WriteLog("Final Weight Received From Kati: " + WT_DATA.Value.ToString());
                        }
                    }
                    BufferString = string.Empty;
                }
            }
            catch (Exception ex) {
                Logger.WriteLog("Error when parsing data: " + ex.Message);
            }
        }
        private void btnShortCut_Click(object sender, EventArgs e) {
            string startupFolder = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            WshShell shell = new WshShell();
            string shortcutAddress = startupFolder + @"\Barcode.lnk";
            IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutAddress);
            shortcut.Description = "A Barcode Interfacer for automated Barcode Printer."; // set the description of the shortcut
            shortcut.WorkingDirectory = Application.StartupPath; /* working directory */
            shortcut.TargetPath = Application.ExecutablePath; /* path of the executable */
            // optionally, you can set the arguments in shortcut.Arguments
            // For example, shortcut.Arguments = "/a 1";
            shortcut.Save();
        }
        private void btnPortSt_Click(object sender, EventArgs e) {
            if (portNameComboBox.SelectedItem != null && portNameComboBox.SelectedItem != null
                            && dataBitsComboBox.SelectedItem != null && parityComboBox.SelectedItem != null
                            && stopBitsComboBox.SelectedItem != null) {
                Properties.Settings.Default.COMPORT = portNameComboBox.SelectedItem.ToString();
                Properties.Settings.Default.BAUD = (int)baudRateComboBox.SelectedItem;
                Properties.Settings.Default.DATABIT_LENGTH = (int)dataBitsComboBox.SelectedItem;
                Properties.Settings.Default.PARITY = (Parity)parityComboBox.SelectedItem;
                Properties.Settings.Default.STOPBIT = (StopBits)stopBitsComboBox.SelectedItem;
                Settings.Default.WebPort = this.txtAPI.Text;
                Properties.Settings.Default.Save();

                this.RunInterfacer();
            }
        }
        private void Form1_Resize(object sender, EventArgs e) {
            //if the form is minimized  
            //hide it from the task bar  
            //and show the system tray icon (represented by the NotifyIcon control)  
            if (this.WindowState == FormWindowState.Minimized) {
                Hide();
                ntfIcon.Visible = true;
            }
        }
        private void ntfIcon_MouseDoubleClick(object sender, MouseEventArgs e) {
            Show();
            this.WindowState = FormWindowState.Normal;
            ntfIcon.Visible = false;
        }
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (sp != null)
                sp.Dispose();
            if (_listener != null && _listener.IsListening) {
                serverFlag = false;
                _listener.Stop();
            }
        }
        
        

    }
}
